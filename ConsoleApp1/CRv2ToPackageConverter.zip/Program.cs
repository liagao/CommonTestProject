﻿namespace ConsoleApp1
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    class Program
    {
        static void Main(string[] args)
        {
            var pluginInfoFilePath = args[0]; //@"D:\PlugIn_to_Nuget__All.tsv";
            var packageInfoFilePath = args[1]; //@"D:\PackageWfPluginMajorVersion.tsv"

            GeneratePackageUpgradeResult(GeneratePluginInfoInCRv2(pluginInfoFilePath), GeneratePackageInfoForPluginInfoInCSharp(packageInfoFilePath));

            Console.WriteLine("Done!");
            Console.ReadLine();
        }

        private static void GeneratePackageUpgradeResult(IEnumerable<PluginInfoInCRv2> pluginInfoList, Dictionary<PluginInfoInCSharp, PackageInfo> packageInfoDic)
        {
            var pluginNotFoundInProductionFeedList = new List<string>();
            var pluginFoundInProductionFeedList = new List<string>();
            var packageWithSingleVersionList = new List<KeyValuePair<string, List<string>>>();
            var packageWithMultipleVersionList = new List<KeyValuePair<string, List<string>>>();

            var packageInfoList = new HashSet<PackageInfo>();
            foreach (var plugin in pluginInfoList)
            {
                var key = packageInfoDic.Keys.FirstOrDefault(o => ComparePluginInfo(plugin, o)>0);
                
                if (key != null)
                {
                    PackageInfo tempPackageInfo = packageInfoDic[key];
                    if(!packageInfoList.Contains(tempPackageInfo))
                    {
                        packageInfoList.Add(tempPackageInfo);
                    }

                    pluginFoundInProductionFeedList.Add($"{plugin.PluginName}\t{plugin.PluginVersion}\t{tempPackageInfo.PackageName}\t{tempPackageInfo.PackageVersion}");
                }
                else
                {
                    pluginNotFoundInProductionFeedList.Add($"{plugin.PluginName}\t{plugin.PluginVersion}");
                }
            }

            // write plugin result in disk
            File.WriteAllLines("Plugin - FoundInProductionFeedList.txt", pluginFoundInProductionFeedList);
            File.WriteAllLines("Plugin - NotFoundInProductionFeedList.txt", pluginNotFoundInProductionFeedList);

            // write package result in disk
            var packageNameWithVersionsDic = new Dictionary<string, List<string>>();

            foreach (var package in packageInfoList)
            {
                List<string> list = null;
                if (packageNameWithVersionsDic.TryGetValue(package.PackageName, out list))
                {
                    list.Add(package.PackageVersion);
                }
                else
                {
                    packageNameWithVersionsDic.Add(package.PackageName, new List<string>() { package.PackageVersion });
                }
            }

            foreach (var item in packageNameWithVersionsDic)
            {
                if (item.Value.Count > 1)
                {
                    packageWithMultipleVersionList.Add(item);
                }
                else
                {
                    packageWithSingleVersionList.Add(item);
                }
            }

            File.WriteAllLines(@"Package - WithSingleVersionList.txt", packageWithSingleVersionList.Select(o => $"{o.Key}\t{o.Value[0]}"));
            File.WriteAllLines(@"Package - WithMultipleVersionList.txt", packageWithMultipleVersionList.Select(o => $"{o.Key}\t{string.Join(",", o.Value)}"));
        }
        
        private static Dictionary<PluginInfoInCSharp, PackageInfo> GeneratePackageInfoForPluginInfoInCSharp(string packageInfoFilePath)
        {
            var packageInfoDic = new Dictionary<PluginInfoInCSharp, PackageInfo>();
            PackageInfo curPackageInfo = null;
            HashSet<string> curGuidList = null;

            foreach (var line in File.ReadAllLines(packageInfoFilePath))
            {
                var sec = line.Split(new []{ '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if(sec.Length < 4)
                {
                    Console.WriteLine(line);
                    continue;
                }
                if(sec.Length > 0)
                {
                    if(sec[0] == "P")
                    {
                        var key = new PluginInfoInCSharp() { PluginName = sec[1], PluginMajorVersion = sec[2], PluginVersion = new Version(sec[3]), PossibleGuidSet = curGuidList };
                        if(packageInfoDic.ContainsKey(key))
                        {
                            if(string.Compare(curPackageInfo.PackageVersion, packageInfoDic[key].PackageVersion, true) > 0)
                            {
                                packageInfoDic[key] = curPackageInfo;
                            }
                        }
                        else
                        {
                            packageInfoDic.Add(key, curPackageInfo);
                        }
                    }
                    else if (sec[0] == "WF")
                    {
                        continue;
                    }
                    else
                    {
                        curPackageInfo = new PackageInfo() { PackageName = sec[0], PackageVersion = sec[1] };
                        curGuidList = new HashSet<string>(sec[2].Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(o => o.Substring(2)));
                    }
                }
            }

            return packageInfoDic;
        }

        private static IEnumerable<PluginInfoInCRv2> GeneratePluginInfoInCRv2(string pluginInfoFilePath)
        {
            foreach(var line in File.ReadAllLines(pluginInfoFilePath).Skip(1))
            {
                var sec = line.Split('\t');
                yield return new PluginInfoInCRv2(sec[0], sec[1], sec[2]);
            }
        }

        private static int ComparePluginInfo(PluginInfoInCRv2 crPlugin, PluginInfoInCSharp csharpPlugin)
        {
            if(string.Equals(crPlugin.PluginNameWithoutGeneric, csharpPlugin.PluginName, StringComparison.OrdinalIgnoreCase) && 
                string.Equals(crPlugin.PluginMajorVersion, csharpPlugin.PluginMajorVersion, StringComparison.OrdinalIgnoreCase))
            {
                // guid found in c# format bilbo: for non-c# migration plugins
                if(csharpPlugin.PossibleGuidSet.Contains(crPlugin.Guid))
                {
                    return 1;
                }
                // major version found in c# format bilbo: for already c# migration plugins
                else if (csharpPlugin.PluginVersion >= crPlugin.PluginVersion)
                {
                    return 2;
                }
            }

            return 0;
        }

    }

    class PluginInfoInCRv2
    {
        public string PluginName { get; set; }
        public string PluginNameWithoutGeneric { get; set; }
        public Version PluginVersion { get; set; }
        public string PluginMajorVersion { get; set; }
        public string Guid { get; set; }

        public PluginInfoInCRv2(string pluginName, string pluginVersion, string guid)
        {
            this.PluginName = pluginName;
            var index = pluginName.IndexOf('{');
            this.PluginNameWithoutGeneric = index > 0 ? pluginName.Substring(0, index): this.PluginName;
            this.PluginMajorVersion = pluginVersion.Split('.')[0];
            this.PluginVersion = new Version(pluginVersion);
            this.Guid = guid;
        }
    }

    class PluginInfoInCSharp
    {
        public string PluginName { get; set; }
        public string PluginMajorVersion { get; set; }
        public Version PluginVersion { get; set; }
        public HashSet<string> PossibleGuidSet { get; set; }

        public override bool Equals(object obj)
        {
            PluginInfoInCSharp plugin2 = obj as PluginInfoInCSharp;
            if(plugin2!=null)
            {
                return string.Equals(plugin2.PluginName, PluginName, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(plugin2.PluginMajorVersion, PluginMajorVersion) && 
                plugin2.PluginVersion == PluginVersion; 
            }

            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return this.PluginName.ToUpper().GetHashCode();
        }
    }

    class PackageInfo
    {
        public string PackageName { get; set; }
        public string PackageVersion { get; set; }

        public override bool Equals(object obj)
        {
            PackageInfo info = obj as PackageInfo;
            return info != null && string.Equals(info.PackageName, PackageName, StringComparison.OrdinalIgnoreCase) &&
                string.Equals(info.PackageVersion, PackageVersion);
        }

        public override int GetHashCode()
        {
            return (this.PackageName + this.PackageVersion).ToUpper().GetHashCode();
        }
    }
}
